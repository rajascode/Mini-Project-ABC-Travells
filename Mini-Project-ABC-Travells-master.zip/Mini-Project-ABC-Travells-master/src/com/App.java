package com;

import java.io.IOException;
import java.security.PublicKey;
import java.text.ParseException;
import java.util.HashMap;

public class App {

	public static void main(String[] args) throws Exception {

		// NewAdminRegistration newAdminRegistration = new NewAdminRegistration();

		Home home_object = new Home();
		//home_object.Home();
		// NewAdminandExistingHome newAdminHome_object = new NewAdminandExistingHome();

	}
}
